@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.dizz.player

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.drawText
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.State
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlin.math.max
import kotlin.math.min
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Bg = Color(0xFF0B0B14)
private val acc: Color get() = Look.accent

class MainActivity : ComponentActivity() {
    private var ctrl: ListenableFuture<MediaController>? = null
    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        App.refresh(this)
        Engine.attach(Audio.player.audioSessionId)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Cfg.init(this); Audio.init(this); Flash.init(this); Templates.refresh(this)
        ctrl = MediaController.Builder(this, SessionToken(this, ComponentName(this, PlaybackService::class.java))).buildAsync()
        val need = ArrayList<String>()
        need.add(if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE)
        need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        perms.launch(need.toTypedArray())
        setContent { DizzApp() }
    }

    override fun onStop() { Cfg.save(); super.onStop() }
    override fun onDestroy() { ctrl?.let { MediaController.releaseFuture(it) }; super.onDestroy() }
}

@Composable
fun DizzApp() {
    var screen by remember { mutableStateOf("lib") }
    val view = LocalView.current
    val keepOn = screen == "player" || (Cfg.flashOn && Cfg.flashMode != 0 && App.playing)
    SideEffect { view.keepScreenOn = keepOn }
    BackHandler(screen != "lib") {
        screen = when (screen) { "edit" -> "lyrics"; "lyrics" -> "player"; else -> "lib" }
    }
    val ac by animateColorAsState(Look.accent, tween(700), label = "acc")
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = ac, onPrimary = Color.White, background = Bg, surface = Bg,
            secondaryContainer = ac.copy(alpha = 0.35f), onSecondaryContainer = Color.White
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Color.Transparent, contentColor = Color.White) {
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(lerp(Bg, ac, 0.28f), Bg, Color(0xFF07070D))))) {
                when (screen) {
                    "lib" -> LibraryScreen { screen = it }
                    "player" -> PlayerScreen { screen = it }
                    "lyrics" -> LyricsScreen { screen = it }
                    "edit" -> EditScreen { screen = it }
                    else -> SettingsScreen { screen = it }
                }
                ScreenFlashOverlay()
                if (screen == "player") CoverLayer()   // обложка поверх визуализации и вспышки
            }
        }
    }
}

// ---------- общие элементы ----------

fun Modifier.glass(r: Dp = 20.dp, a: Float = 0.07f): Modifier =
    this.clip(RoundedCornerShape(r)).background(Color.White.copy(alpha = a))
        .border(1.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(r))

@Composable
fun RoundIcon(onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.10f)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
fun Pill(s: String, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(20.dp)).background(Color.White.copy(alpha = 0.10f)).clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 9.dp)
    ) { Text(s, fontSize = 13.sp) }
}

@Composable
fun PlayButton(size: Dp, onClick: () -> Unit) {
    Box(
        Modifier.size(size).clip(CircleShape)
            .background(Brush.linearGradient(listOf(acc, hueShift(acc, 50f)))).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(if (App.playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, Modifier.size(size / 2), tint = Color.White)
    }
}

@Composable
fun Avatar(t: Track, cur: Boolean, size: Dp = 48.dp) {
    val img = if (cur) Look.cover else null
    val h = ((t.title.hashCode() and 0x7fffffff) % 360).toFloat()
    Box(
        Modifier.size(size).clip(RoundedCornerShape(size / 3.5f))
            .background(Brush.linearGradient(listOf(Color.hsv(h, 0.55f, 0.95f), Color.hsv((h + 50f) % 360f, 0.75f, 0.55f)))),
        contentAlignment = Alignment.Center
    ) {
        if (img != null) Image(img, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text(t.title.take(1).uppercase(), fontWeight = FontWeight.Bold, color = Color.White, fontSize = 18.sp)
    }
}

@Composable
fun Chips(items: List<String>, sel: Int, on: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEachIndexed { i, s -> FilterChip(selected = i == sel, onClick = { on(i) }, label = { Text(s) }) }
    }
}

@Composable
fun Lt(s: String, size: Int, a: Float, bold: Boolean = false) {
    Text(
        s, fontSize = size.sp, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        color = Color.White.copy(alpha = a), textAlign = TextAlign.Center, maxLines = 2,
        style = TextStyle(shadow = Shadow(Color.Black, Offset(0f, 2f), 10f)),
        modifier = Modifier.padding(vertical = 2.dp)
    )
}

@Composable
fun VizView(modifier: Modifier) {
    val ctx = LocalContext.current
    val ti = Cfg.style - STYLES.size
    val name = if (ti >= 0) Templates.names.getOrNull(ti) else null
    val scene = remember(name) { name?.let { Templates.scene(ctx, it) } }
    val tpl = scene != null
    LaunchedEffect(tpl) {
        var last = 0L
        val gap = if (tpl) 30_000_000L else 15_000_000L   // шаблоны ~33 к/с, встроенные ~60 к/с (даже на 120 Гц)
        while (true) {
            withFrameNanos { n ->
                if (n - last >= gap) {
                    val dt = if (last == 0L) 0.016f else ((n - last) / 1e9f).coerceAtMost(0.1f)
                    last = n
                    Engine.step(dt)
                    Clock.t = n
                }
            }
        }
    }
    Canvas(modifier) {
        val t = Clock.t / 1_000_000_000f
        var drawn = false
        val sc = scene
        if (sc != null && sc.ok) {
            val p = Audio.player
            val inf = Info(p.currentPosition, p.duration.coerceAtLeast(0L), App.current?.title ?: "", App.current?.artist ?: "")
            drawIntoCanvas { c ->
                try {
                    sc.draw(c.nativeCanvas, size.width, size.height, inf, Cfg.vizQuality, Cfg.vizTrails)
                    drawn = true
                } catch (e: Throwable) {
                    sc.ok = false
                    Templates.lastError = "Ошибка шаблона: " + (e.message ?: e.javaClass.simpleName)
                }
            }
        }
        if (!drawn) drawViz(t)
    }
}

// ---------- анимированный текст ----------

/** Доля заполнения строки: от метки строки до следующей (с небольшим запасом до конца). */
fun lineProgress(lines: List<LrcLine>, i: Int, pos: Long): Float {
    val c = lines.getOrNull(i) ?: return 0f
    val n = lines.getOrNull(i + 1)
    val span = ((n?.t ?: (c.t + 4000L)) - c.t).coerceIn(700L, 8000L) * 0.92f
    return ((pos - c.t) / span).coerceIn(0f, 1f)
}

/**
 * Караоке-заливка: тусклый текст, поверх которого плавно, пиксель за пикселем, слева направо
 * проявляется яркий. Если строка переносится, заливка идёт по строкам подряд.
 * progress читается только в фазе рисования — перекомпоновки на каждый кадр нет.
 */
@Composable
fun KaraokeText(text: String, progress: () -> Float, sizeSp: Float, center: Boolean, modifier: Modifier = Modifier) {
    val tm = rememberTextMeasurer()
    val dens = LocalDensity.current
    BoxWithConstraints(modifier.fillMaxWidth()) {
        val maxW = constraints.maxWidth
        val style = TextStyle(
            fontSize = sizeSp.sp, fontWeight = FontWeight.Bold, lineHeight = (sizeSp * 1.25f).sp,
            textAlign = if (center) TextAlign.Center else TextAlign.Start
        )
        val layout = remember(text, maxW, sizeSp, center) { tm.measure(text, style, constraints = Constraints(maxWidth = maxW)) }
        val hDp = with(dens) { layout.size.height.toDp() }
        Canvas(Modifier.fillMaxWidth().height(hDp)) {
            drawText(layout, color = Color.White.copy(alpha = 0.38f), shadow = Shadow(Color.Black.copy(alpha = 0.6f), Offset(0f, 3f), 10f))
            val n = layout.lineCount
            var total = 0f
            for (i in 0 until n) total += layout.getLineRight(i) - layout.getLineLeft(i)
            var left = progress().coerceIn(0f, 1f) * total
            val glow = Shadow(Look.accent.copy(alpha = 0.85f), Offset.Zero, 20f)
            for (i in 0 until n) {
                val l = layout.getLineLeft(i)
                val r = layout.getLineRight(i)
                val w = max(1f, r - l)
                val frac = (left / w).coerceIn(0f, 1f)
                left -= w
                if (frac <= 0f) continue
                val feather = 0.07f
                val brush = if (frac >= 1f) SolidColor(Color.White)
                else Brush.horizontalGradient(0f to Color.White, frac to Color.White, min(1f, frac + feather) to Color.Transparent, startX = l, endX = r)
                val clipR = if (frac >= 1f) size.width else l + w * min(1f, frac + feather)
                clipRect(0f, layout.getLineTop(i), clipR, layout.getLineBottom(i)) {
                    drawText(layout, brush = brush, shadow = glow)
                }
            }
        }
    }
}

@Composable
fun LyricsBlock(lines: List<LrcLine>, synced: Boolean, idx: Int, posS: State<Long>, open: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = open).padding(vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        when {
            lines.isEmpty() -> Lt("Текста пока нет — нажмите, чтобы найти или написать", 14, 0.6f)
            !synced -> Lt("Текст без меток времени — «Правка» → «Вставить время»", 14, 0.7f)
            else -> AnimatedContent(
                targetState = idx,
                transitionSpec = {
                    (slideInVertically(tween(380)) { it / 3 } + fadeIn(tween(380))) togetherWith
                        (slideOutVertically(tween(260)) { -it / 3 } + fadeOut(tween(200)))
                },
                label = "line"
            ) { i ->
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Lt(lines.getOrNull(i - 1)?.text.orEmpty().ifBlank { " " }, 15, 0.45f)
                    val cur = lines.getOrNull(i)
                    if (cur != null) KaraokeText(cur.text.ifBlank { "♪" }, { lineProgress(lines, i, posS.value) }, 26f, true)
                    else Lt(" ", 26, 0f)
                    Lt(lines.getOrNull(i + 1)?.text.orEmpty().ifBlank { " " }, 16, 0.55f)
                }
            }
        }
    }
}

/** Позиция воспроизведения, обновляется раз в кадр и читается только там, где нужна. */
@Composable
fun rememberPos(): State<Long> = produceState(0L) {
    var last = 0L
    while (true) {
        withFrameNanos { n ->
            if (n - last >= 16_000_000L) { last = n; value = Audio.player.currentPosition }
        }
    }
}

@Composable
fun SeekRow(posS: State<Long>, dur: Long, onSeek: (Long) -> Unit) {
    val pos = posS.value
    var drag by remember { mutableStateOf<Float?>(null) }
    Slider(
        value = drag ?: (pos.toFloat() / dur).coerceIn(0f, 1f),
        onValueChange = { drag = it },
        onValueChangeFinished = { drag?.let { onSeek((it * dur).toLong()) }; drag = null },
        colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = acc, inactiveTrackColor = Color.White.copy(alpha = 0.2f))
    )
    Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp)) {
        Text(Lyrics.fmt(pos).take(5), fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f))
        Spacer(Modifier.weight(1f))
        Text(Lyrics.fmt(dur).take(5), fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f))
    }
}

// ---------- библиотека ----------

@Composable
fun LibraryScreen(go: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var job by remember { mutableStateOf<Job?>(null) }
    val list = remember(App.tracks, q) {
        if (q.isBlank()) App.tracks else App.tracks.filter { (it.title + " " + it.artist).contains(q, true) }
    }

    fun startBatch() {
        job = scope.launch(Dispatchers.IO) {
            val todo = App.tracks.filter { it.id !in App.lyricIds }
            var ok = 0
            for ((i, t) in todo.withIndex()) {
                ensureActive()
                status = "Ищу ${i + 1}/${todo.size}: ${t.title}"
                var text = try { Net.lrclib(t) } catch (e: Exception) { null }
                if (text == null && Cfg.aiInBatch && Cfg.apiKey.isNotBlank()) {
                    status = "ИИ слушает ${i + 1}/${todo.size}: ${t.title}"
                    text = try { Net.transcribe(ctx, t) } catch (e: Exception) { null }
                }
                if (text != null) { Lyrics.save(ctx, t.id, text); ok++ }
            }
            status = "Готово: найдено $ok из ${todo.size}"
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    "DizzPlayer", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold,
                    style = TextStyle(brush = Brush.horizontalGradient(listOf(acc, hueShift(acc, 60f))))
                )
                Text("${App.tracks.size} треков · ${App.lyricIds.size} с текстом", fontSize = 12.sp, color = Color.White.copy(alpha = 0.5f))
            }
            RoundIcon({ go("settings") }) { Icon(Icons.Default.Settings, null) }
        }
        OutlinedTextField(
            q, { q = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), singleLine = true,
            placeholder = { Text("Поиск по трекам") }, shape = RoundedCornerShape(28.dp),
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedBorderColor = Color.White.copy(alpha = 0.12f), focusedBorderColor = acc,
                unfocusedContainerColor = Color.White.copy(alpha = 0.05f), focusedContainerColor = Color.White.copy(alpha = 0.07f)
            )
        )
        Row(Modifier.padding(horizontal = 16.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            if (job?.isActive == true) Button({ job?.cancel(); status = "Остановлено" }, shape = RoundedCornerShape(24.dp)) { Text("Стоп") }
            else Button({ startBatch() }, shape = RoundedCornerShape(24.dp)) { Text("Найти тексты для всех") }
            Spacer(Modifier.width(10.dp))
            Text(status, fontSize = 12.sp, maxLines = 2, color = Color.White.copy(alpha = 0.5f))
        }
        if (App.tracks.isEmpty()) Text("Треков не найдено. Дайте доступ к аудио в настройках телефона.", Modifier.padding(20.dp), color = Color.Gray)
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(top = 8.dp)) {
            itemsIndexed(list, key = { _, t -> t.id }) { i, t ->
                val cur = App.current?.id == t.id
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 2.dp).clip(RoundedCornerShape(16.dp))
                        .background(if (cur) acc.copy(alpha = 0.14f) else Color.Transparent)
                        .clickable { App.play(list, i); go("player") }.padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(t, cur)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(t.title, maxLines = 1, fontWeight = FontWeight.Medium, color = if (cur) acc else Color.White)
                        Text(t.artist.ifBlank { "Неизвестный исполнитель" }, fontSize = 12.sp, color = Color.White.copy(alpha = 0.5f), maxLines = 1)
                    }
                    if (t.id in App.lyricIds) Text("♪", color = acc, fontSize = 18.sp, modifier = Modifier.padding(end = 6.dp))
                }
            }
        }
        App.current?.let { t ->
            Row(
                Modifier.fillMaxWidth().padding(12.dp).glass(24.dp, 0.10f).clickable { go("player") }.padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Avatar(t, true, 44.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(t.title, maxLines = 1, fontWeight = FontWeight.Medium)
                    Text(t.artist.ifBlank { "—" }, fontSize = 11.sp, color = Color.White.copy(alpha = 0.5f), maxLines = 1)
                }
                PlayButton(44.dp) { if (App.playing) Audio.player.pause() else Audio.player.play() }
            }
        }
    }
}

// ---------- плеер ----------

@Composable
fun PlayerScreen(go: (String) -> Unit) {
    val ctx = LocalContext.current
    val p = Audio.player
    val t = App.current
    val posS = rememberPos()
    val dur = (if (p.duration > 0) p.duration else (t?.durMs ?: 1L)).coerceAtLeast(1L)
    val lines = remember(t?.id, App.rev) { t?.let { Lyrics.load(ctx, it.id) }?.let { Lyrics.parse(it) } ?: emptyList() }
    val synced = lines.isNotEmpty() && lines[0].t >= 0
    val idx by remember(lines) { derivedStateOf { if (synced) idxAt(lines, posS.value) else -1 } }
    val micOk = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    Box(Modifier.fillMaxSize()) {
        VizView(Modifier.fillMaxSize())
        Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                RoundIcon({ go("lib") }) { Icon(Icons.Default.ArrowBack, null) }
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(t?.title ?: "", maxLines = 1, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(t?.artist ?: "", fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f), maxLines = 1)
                }
                RoundIcon({ Cfg.flashOn = !Cfg.flashOn }) {
                    Icon(Icons.Default.FlashOn, null, tint = if (Cfg.flashOn) Color.Yellow else Color.White.copy(alpha = 0.6f))
                }
                Spacer(Modifier.width(8.dp))
                RoundIcon({ go("settings") }) { Icon(Icons.Default.Settings, null) }
            }
            Spacer(Modifier.height(10.dp))
            Chips(STYLES + Templates.names, Cfg.style) { Cfg.style = it }
            if (!micOk) Text(
                "Для визуализации нужно разрешение «Микрофон» (используется только для анализа звука плеера).",
                fontSize = 11.sp, color = Color(0xFFFF8A80), modifier = Modifier.padding(top = 6.dp)
            )
            if (Templates.lastError.isNotEmpty()) Text(Templates.lastError, fontSize = 11.sp, color = Color(0xFFFF8A80), modifier = Modifier.padding(top = 6.dp))
            Spacer(Modifier.weight(1f))
            LyricsBlock(lines, synced, idx, posS) { go("lyrics") }
            Spacer(Modifier.height(10.dp))
            Column(
                Modifier.fillMaxWidth().glass(28.dp, 0.10f).background(Color.Black.copy(alpha = 0.25f))
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                SeekRow(posS, dur) { p.seekTo(it) }
                Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Pill("Текст") { go("lyrics") }
                    IconButton({ p.seekToPrevious() }, Modifier.size(52.dp)) { Icon(Icons.Default.SkipPrevious, null, Modifier.size(34.dp)) }
                    PlayButton(68.dp) { if (App.playing) p.pause() else p.play() }
                    IconButton({ p.seekToNext() }, Modifier.size(52.dp)) { Icon(Icons.Default.SkipNext, null, Modifier.size(34.dp)) }
                    Pill("Правка") { go("edit") }
                }
            }
        }
    }
}

// ---------- текст песни ----------

@Composable
fun LyricsScreen(go: (String) -> Unit) {
    val t = App.current
    if (t == null) { Text("Сначала выберите трек", Modifier.padding(24.dp)); return }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val p = Audio.player
    val posS = rememberPos()
    val lines = remember(t.id, App.rev) { Lyrics.load(ctx, t.id)?.let { Lyrics.parse(it) } ?: emptyList() }
    val synced = lines.isNotEmpty() && lines[0].t >= 0
    val idx by remember(lines) { derivedStateOf { if (synced) idxAt(lines, posS.value) else -1 } }
    val ls = rememberLazyListState()
    LaunchedEffect(idx) { if (idx >= 0) ls.animateScrollToItem((idx - 2).coerceAtLeast(0)) }
    var busy by remember { mutableStateOf("") }
    var ask by remember { mutableStateOf<(() -> Unit)?>(null) }

    fun online() {
        scope.launch {
            busy = "Ищу текст в интернете…"
            val r = withContext(Dispatchers.IO) { runCatching { Net.lrclib(t) }.getOrNull() }
            if (r != null) { Lyrics.save(ctx, t.id, r); busy = "Найдено" } else busy = "Не найдено. Попробуйте ИИ-распознавание."
        }
    }
    fun ai() {
        scope.launch {
            busy = "ИИ слушает песню… (до минуты)"
            val r = withContext(Dispatchers.IO) { runCatching { Net.transcribe(ctx, t) } }
            r.onSuccess { Lyrics.save(ctx, t.id, it); busy = "Готово. Проверьте текст и поправьте в «Править»" }
                .onFailure { busy = "Ошибка: ${it.message}" }
        }
    }
    fun guard(a: () -> Unit) { if (lines.isNotEmpty()) ask = a else a() }

    ask?.let { a ->
        AlertDialog(
            onDismissRequest = { ask = null },
            title = { Text("Заменить текущий текст?") },
            text = { Text("Ваши правки будут потеряны.") },
            confirmButton = { TextButton({ ask = null; a() }) { Text("Заменить") } },
            dismissButton = { TextButton({ ask = null }) { Text("Отмена") } }
        )
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            RoundIcon({ go("player") }) { Icon(Icons.Default.ArrowBack, null) }
            Column(Modifier.padding(start = 12.dp)) {
                Text(t.title, maxLines = 1, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(t.artist, maxLines = 1, fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f))
            }
        }
        Row(Modifier.padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill("Искать") { guard { online() } }
            Pill("ИИ") { guard { ai() } }
            Pill("Править") { go("edit") }
        }
        if (busy.isNotEmpty()) Text(busy, fontSize = 12.sp, color = acc, modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp))
        LazyColumn(state = ls, modifier = Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp)) {
            if (lines.isEmpty()) item {
                Text("Текста пока нет.\n«Искать» — бесплатная база онлайн, «ИИ» — распознать голос в песне, «Править» — вставить свой.", color = Color.Gray)
            }
            itemsIndexed(lines) { i, l ->
                val cur = i == idx
                val a by animateFloatAsState(if (cur) 1f else if (synced) 0.4f else 0.9f, tween(300), label = "la")
                val sc by animateFloatAsState(if (cur) 1f else 0.86f, tween(300), label = "ls")
                Box(
                    Modifier.fillMaxWidth().clickable(enabled = synced) { p.seekTo(l.t) }.padding(vertical = 8.dp)
                        .graphicsLayer { scaleX = sc; scaleY = sc; alpha = a; transformOrigin = TransformOrigin(0f, 0.5f) }
                ) {
                    if (cur) KaraokeText(l.text.ifBlank { "♪" }, { lineProgress(lines, i, posS.value) }, 24f, false)
                    else Text(l.text.ifBlank { "♪" }, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

private fun stamp(tf: TextFieldValue, pos: Long): TextFieldValue {
    val text = tf.text
    val s = tf.selection.start.coerceIn(0, text.length)
    val ls = text.lastIndexOf('\n', s - 1) + 1
    var le = text.indexOf('\n', ls)
    if (le < 0) le = text.length
    val line = text.substring(ls, le).replace(Regex("^(\\[\\d+:\\d+([.:]\\d+)?])+"), "")
    val ins = "[${Lyrics.fmt(pos)}]$line"
    val res = text.substring(0, ls) + ins + text.substring(le)
    return TextFieldValue(res, TextRange((ls + ins.length + 1).coerceAtMost(res.length)))
}

@Composable
fun EditScreen(go: (String) -> Unit) {
    val t = App.current
    if (t == null) { Text("Сначала выберите трек", Modifier.padding(24.dp)); return }
    val ctx = LocalContext.current
    val p = Audio.player
    val pos by produceState(0L) { while (true) { value = p.currentPosition; delay(50) } }
    var tf by remember { mutableStateOf(TextFieldValue(Lyrics.load(ctx, t.id) ?: "")) }

    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            RoundIcon({ go("lyrics") }) { Icon(Icons.Default.ArrowBack, null) }
            Text("Правка: ${t.title}", Modifier.weight(1f).padding(horizontal = 12.dp), maxLines = 1, fontWeight = FontWeight.Bold)
            Button({ Lyrics.save(ctx, t.id, tf.text); go("lyrics") }, shape = RoundedCornerShape(24.dp)) { Text("Сохранить") }
        }
        Row(Modifier.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            PlayButton(44.dp) { if (App.playing) p.pause() else p.play() }
            Spacer(Modifier.width(12.dp))
            Text(Lyrics.fmt(pos), color = acc, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(12.dp))
            Pill("Вставить время") { tf = stamp(tf, pos) }
        }
        Text(
            "Формат строки: [мм:сс.хх] слова. Поставьте курсор в строку и нажмите «Вставить время» в момент, когда её поют — курсор перейдёт на следующую строку. Пустой текст = удалить.",
            fontSize = 11.sp, color = Color.White.copy(alpha = 0.5f), modifier = Modifier.padding(bottom = 6.dp)
        )
        OutlinedTextField(
            tf, { tf = it }, Modifier.weight(1f).fillMaxWidth(), shape = RoundedCornerShape(20.dp),
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedBorderColor = Color.White.copy(alpha = 0.12f), focusedBorderColor = acc,
                unfocusedContainerColor = Color.White.copy(alpha = 0.05f), focusedContainerColor = Color.White.copy(alpha = 0.07f)
            )
        )
    }
}

// ---------- настройки ----------

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 14.dp).glass(22.dp).padding(16.dp)) {
        Text(title, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = acc)
        Spacer(Modifier.height(6.dp))
        content()
    }
}

@Composable
fun Sl(label: String, v: Float, r: ClosedFloatingPointRange<Float>, shown: String, set: (Float) -> Unit) {
    Text("$label: $shown", fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
    Slider(v, set, valueRange = r)
}

@Composable
fun SwitchRow(label: String, v: Boolean, set: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(v, set)
    }
}

@Composable
fun SettingsScreen(go: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var vizMsg by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            vizMsg = "Импорт…"
            vizMsg = withContext(Dispatchers.IO) {
                try { "Импортировано: " + Templates.import(ctx, uri) } catch (e: Exception) { "Ошибка: " + e.message }
            }
            Templates.refresh(ctx)
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            RoundIcon({ go("lib") }) { Icon(Icons.Default.ArrowBack, null) }
            Text("Настройки", fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 12.dp))
        }
        Section("Визуализация") {
            Chips(STYLES + Templates.names, Cfg.style) { Cfg.style = it }
            Spacer(Modifier.height(8.dp))
            Chips(PALETTES, Cfg.palette) { Cfg.palette = it }
            Sl("Чувствительность", Cfg.gain, 0.5f..2.5f, "${(Cfg.gain * 100).toInt()}%") { Cfg.gain = it }
            SwitchRow("Частицы", Cfg.particles) { Cfg.particles = it }
        }
        Section("Шаблоны Avee Player (.viz)") {
            Text(
                "Импортируйте файл .viz — шаблон появится рядом со стилями визуализации на экране плеера. Шаблон рисуется видеокартой в полном разрешении. Поддержаны слои: картинки и маски, столбики спектра, частицы, текст, блюр-свечение (Android 12+), RGB-сплит, зеркало, моушн-блюр.",
                fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f)
            )
            Button({ picker.launch(arrayOf("*/*")) }, Modifier.padding(top = 10.dp), shape = RoundedCornerShape(24.dp)) { Text("Импортировать .viz") }
            if (vizMsg.isNotEmpty()) Text(vizMsg, fontSize = 12.sp, color = acc, modifier = Modifier.padding(top = 6.dp))
            Templates.names.forEach { n ->
                Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(n, Modifier.weight(1f), maxLines = 1)
                    TextButton({ Templates.delete(ctx, n) }) { Text("Удалить") }
                }
            }
            Sl("Детализация (частицы, свечение)", Cfg.vizQuality, 0.2f..1f, "${(Cfg.vizQuality * 100).toInt()}%") { Cfg.vizQuality = it }
            SwitchRow("Шлейф моушн-блюра (нагружает видеокарту)", Cfg.vizTrails) { Cfg.vizTrails = it }
            if (Templates.lastError.isNotEmpty()) Text(Templates.lastError, fontSize = 12.sp, color = Color(0xFFFF8A80), modifier = Modifier.padding(top = 6.dp))
        }
        Section("Обложка") {
            SwitchRow("Показывать обложку поверх визуализации", Cfg.showCover) { Cfg.showCover = it }
            Chips(listOf("Круг", "Скруглённый квадрат"), Cfg.coverShape) { Cfg.coverShape = it }
            Sl("Размер обложки", Cfg.coverSize, 0.25f..0.7f, "${(Cfg.coverSize * 100).toInt()}%") { Cfg.coverSize = it }
            Text("Берётся из тегов трека. Если обложки нет — не показывается.", fontSize = 11.sp, color = Color.White.copy(alpha = 0.5f))
        }
        Section("Вспышка под бит") {
            SwitchRow("Включить вспышку", Cfg.flashOn) { Cfg.flashOn = it }
            Chips(listOf("Фонарик", "Экран", "Оба"), Cfg.flashMode) { Cfg.flashMode = it }
            if (Cfg.flashMode != 1 && !Flash.available) Text("Фонарик на этом устройстве не найден", color = Color(0xFFFF6B6B))
            Text("Реагировать на", fontSize = 13.sp, modifier = Modifier.padding(top = 12.dp, bottom = 4.dp))
            Chips(listOf("Бас", "Середина", "Верха", "Всё"), Cfg.flashBand) { Cfg.flashBand = it }
            Sl("Чувствительность к биту", Cfg.flashSens, 0f..1f, "${(Cfg.flashSens * 100).toInt()}%") { Cfg.flashSens = it }
            Sl("Мин. пауза между вспышками", Cfg.flashGap, 100f..600f, "${Cfg.flashGap.toInt()} мс") { Cfg.flashGap = it }
            if (Cfg.flashMode != 0) {
                Text("Вспышка экрана", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp))
                Sl("Яркость вспышки", Cfg.screenBright, 0.1f..1f, "${(Cfg.screenBright * 100).toInt()}%") { Cfg.screenBright = it }
                Sl("Длительность (затухание)", Cfg.screenLen, 50f..800f, "${Cfg.screenLen.toInt()} мс") { Cfg.screenLen = it }
                Text("Цвет", fontSize = 13.sp, modifier = Modifier.padding(top = 12.dp))
                ColorPicker()
            }
            if (Cfg.flashMode != 1) {
                Text("Фонарик", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp))
                Sl("Длина вспышки", Cfg.flashLen, 20f..200f, "${Cfg.flashLen.toInt()} мс") { Cfg.flashLen = it }
                if (Flash.hasStrength) Sl("Яркость фонарика", Cfg.flashBright, 0.1f..1f, "${(Cfg.flashBright * 100).toInt()}%") { Cfg.flashBright = it }
            }
            Button({
                if (Cfg.flashMode != 1) Flash.pulse()
                if (Cfg.flashMode != 0) ScreenFlash.pulse()
            }, Modifier.padding(top = 12.dp), shape = RoundedCornerShape(24.dp)) { Text("Тест вспышки") }
            Text(
                "⚠ Мигающий свет может спровоцировать приступ при фоточувствительной эпилепсии. Яркая вспышка экрана в темноте бьёт по глазам — начните с малой яркости.",
                fontSize = 11.sp, color = Color.White.copy(alpha = 0.5f), modifier = Modifier.padding(top = 6.dp)
            )
        }
        Section("ИИ-тексты") {
            Chips(listOf("Groq (бесплатно)", "OpenAI"), Cfg.provider) { Cfg.provider = it }
            OutlinedTextField(
                Cfg.apiKey, { Cfg.apiKey = it.trim() }, Modifier.fillMaxWidth().padding(top = 8.dp), singleLine = true,
                label = { Text("API-ключ") }, visualTransformation = PasswordVisualTransformation()
            )
            OutlinedTextField(
                Cfg.aiLang, { Cfg.aiLang = it.take(5) }, Modifier.fillMaxWidth().padding(top = 8.dp), singleLine = true,
                label = { Text("Язык песен (ru, en… пусто = авто)") }
            )
            SwitchRow("В массовом поиске: если текста нет в базе — распознавать ИИ", Cfg.aiInBatch) { Cfg.aiInBatch = it }
            Text(
                "Ключ Groq: console.groq.com → API Keys. Файл трека до 25 МБ. Распознавание пения может ошибаться — тексты можно поправить в «Править».",
                fontSize = 11.sp, color = Color.White.copy(alpha = 0.5f)
            )
        }
        Spacer(Modifier.height(32.dp))
    }
}

@Composable
fun ColorPicker() {
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically
    ) {
        FLASH_COLORS.forEachIndexed { i, (_, c) ->
            val sel = Cfg.screenColor == i
            Box(
                Modifier.size(38.dp).clip(CircleShape).background(c)
                    .border(if (sel) 3.dp else 1.dp, if (sel) Color.White else Color.Gray, CircleShape)
                    .clickable { Cfg.screenColor = i }
            )
        }
    }
    Chips(listOf("Свой оттенок", "Радуга"), Cfg.screenColor - FLASH_COLORS.size) { Cfg.screenColor = FLASH_COLORS.size + it }
    if (Cfg.screenColor == FLASH_COLORS.size) {
        Sl("Оттенок", Cfg.screenHue, 0f..360f, "${Cfg.screenHue.toInt()}°") { Cfg.screenHue = it }
        Box(Modifier.padding(top = 4.dp).fillMaxWidth().height(28.dp).clip(RoundedCornerShape(8.dp)).background(Color.hsv(Cfg.screenHue.coerceIn(0f, 360f), 1f, 1f)))
    } else if (Cfg.screenColor > FLASH_COLORS.size) {
        Text("Цвет меняется на каждый удар", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(top = 6.dp))
    }
}
