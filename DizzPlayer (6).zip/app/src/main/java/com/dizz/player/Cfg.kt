package com.dizz.player

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

object Cfg {
    private var sp: SharedPreferences? = null
    var apiKey by mutableStateOf("")
    var provider by mutableIntStateOf(0)       // 0 = Groq, 1 = OpenAI
    var aiLang by mutableStateOf("")
    var aiInBatch by mutableStateOf(false)
    var style by mutableIntStateOf(0)
    var palette by mutableIntStateOf(0)
    var gain by mutableFloatStateOf(1f)
    var particles by mutableStateOf(true)
    var flashOn by mutableStateOf(false)
    var flashBand by mutableIntStateOf(0)      // 0 bass, 1 mid, 2 high, 3 all
    var flashSens by mutableFloatStateOf(0.6f)
    var flashLen by mutableFloatStateOf(70f)
    var flashGap by mutableFloatStateOf(200f)
    var flashBright by mutableFloatStateOf(1f)
    var flashMode by mutableIntStateOf(1)        // 0 фонарик, 1 экран, 2 оба
    var screenColor by mutableIntStateOf(0)      // 0..8 цвета, 9 свой, 10 радуга
    var screenHue by mutableFloatStateOf(280f)
    var screenBright by mutableFloatStateOf(0.8f)
    var screenLen by mutableFloatStateOf(220f)
    var showCover by mutableStateOf(true)
    var coverShape by mutableIntStateOf(0)       // 0 круг, 1 скруглённый квадрат
    var coverSize by mutableFloatStateOf(0.42f)
    var vizQuality by mutableFloatStateOf(0.7f)
    var vizTrails by mutableStateOf(false)

    fun init(c: Context) {
        if (sp != null) return
        val s = c.getSharedPreferences("dizz", Context.MODE_PRIVATE)
        sp = s
        apiKey = s.getString("apiKey", "") ?: ""
        provider = s.getInt("provider", 0)
        aiLang = s.getString("aiLang", "") ?: ""
        aiInBatch = s.getBoolean("aiInBatch", false)
        style = s.getInt("style", 0)
        palette = s.getInt("palette", 0)
        gain = s.getFloat("gain", 1f)
        particles = s.getBoolean("particles", true)
        flashOn = s.getBoolean("flashOn", false)
        flashBand = s.getInt("flashBand", 0)
        flashSens = s.getFloat("flashSens", 0.6f)
        flashLen = s.getFloat("flashLen", 70f)
        flashGap = s.getFloat("flashGap", 200f)
        flashBright = s.getFloat("flashBright", 1f)
        flashMode = s.getInt("flashMode", 1)
        screenColor = s.getInt("screenColor", 0)
        screenHue = s.getFloat("screenHue", 280f)
        screenBright = s.getFloat("screenBright", 0.8f)
        screenLen = s.getFloat("screenLen", 220f)
        showCover = s.getBoolean("showCover", true)
        coverShape = s.getInt("coverShape", 0)
        coverSize = s.getFloat("coverSize", 0.42f)
        vizQuality = s.getFloat("vizQuality", 0.7f)
        vizTrails = s.getBoolean("vizTrails", false)
    }

    fun save() {
        val e = sp?.edit() ?: return
        e.putString("apiKey", apiKey)
        e.putInt("provider", provider)
        e.putString("aiLang", aiLang)
        e.putBoolean("aiInBatch", aiInBatch)
        e.putInt("style", style)
        e.putInt("palette", palette)
        e.putFloat("gain", gain)
        e.putBoolean("particles", particles)
        e.putBoolean("flashOn", flashOn)
        e.putInt("flashBand", flashBand)
        e.putFloat("flashSens", flashSens)
        e.putFloat("flashLen", flashLen)
        e.putFloat("flashGap", flashGap)
        e.putFloat("flashBright", flashBright)
        e.putInt("flashMode", flashMode)
        e.putInt("screenColor", screenColor)
        e.putFloat("screenHue", screenHue)
        e.putFloat("screenBright", screenBright)
        e.putFloat("screenLen", screenLen)
        e.putBoolean("showCover", showCover)
        e.putInt("coverShape", coverShape)
        e.putFloat("coverSize", coverSize)
        e.putFloat("vizQuality", vizQuality)
        e.putBoolean("vizTrails", vizTrails)
        e.apply()
    }
}
